<?php echo e($slot); ?>

<?php /**PATH F:\Project\NEW\WarungIrfan - Copy - Copy\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>