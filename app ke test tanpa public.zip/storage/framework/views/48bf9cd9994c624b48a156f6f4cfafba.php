<footer class="footer">
  <div class="container-fluid">
    
  </div>
</footer><?php /**PATH F:\Project\NEW\WarungIrfan - Copy\resources\views/layouts/src/adminfooter.blade.php ENDPATH**/ ?>