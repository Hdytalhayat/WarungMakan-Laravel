

<?php $__env->startSection('title'); ?>
    Add Menu
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-12">
            <div class="card">/
                <div class="card-header">
                    <h4>Add Menu</h4>
                </div>
                <div class="card-body">
                    <form action="<?php echo e(url('insert-menu')); ?>" method="POST" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <div class="row">
                            <div class="col-md-12 mb-3">
                                <select class="form-select" name="cate_id" required>
                                    <option selected>Select a Categories</option>
                                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($item->id); ?>"><?php echo e($item->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                  </select>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label for="">Name</label>
                                <input type="text" class="form-control" name='name' required>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label for="">Slug</label>
                                <input type="text" class="form-control" name='slug' placeholder="untuk url" required>
                            </div>
                            <div class="col-md-12 mb-3">
                                <label for="">Small Description</label>
                                <textarea name="small_description" rows="3" class="form-control" required></textarea>
                            </div>
                            <div class="col-md-12 mb-3">
                                <label for="">Description</label>
                                <textarea name="description" rows="3" class="form-control" required></textarea>
                            </div>
                            
                            <div class="col-md-3 mb-3">
                                <label for="">Original Price</label>
                                <input type="number" class="form-control" name='original_price' placeholder="10000" required>
                            </div>
                            <div class="col-md-3 mb-3">
                                <label for="">Promo Price</label>
                                <input type="number" class="form-control" name='menu_price' placeholder="Isi jika ada promo">
                            </div>
                            <div class="col-md-6 mb-3">
                                <label for="">Hidden</label>
                                <span class="fs-6 fw-light">*jangan cek jika ingin visible</span>
                                <input type="checkbox" class="form-control" name='status'>
                            </div>
                            <div class="col-md-12">
                                <label for="">Image</label>
                                <input type="file" accept=".jfif,.jpeg,.jpg,.png" name="image" class="form-control" required>
                            </div>
                            <div class="col-md-12">
                                <label for="">Model 3D (.glb)</label>
                                <input type="file" accept=".glb" name="model" class="form-control" required>
                            </div>
                            <div class="col-md-12">
                                <button type="submit" name="image" class="btn btn-primary">Submit</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
    
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Project\NEW\WarungIrfan - Copy - Copy\resources\views/admin/menu/add.blade.php ENDPATH**/ ?>