

<?php $__env->startSection('title'); ?>
    Warung Irfan
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="hero">
    <div class="container">
        <div class="row justify-content-between">
            <div class="col-lg-5">
                <div class="intro-excerpt">
                    <h1 class="animate__animated animate__fadeInDown">Selamat Datang<span class="d-block">Berkunjung</span></h1>
                    <p class="mb-4">Website ini dibuat untuk memudahkan para penggunanya untuk memesan makanan dengan cara yang fleksibel</p>
                    <p><a href="view-categories/" class="btn btn-secondary me-2">Beii Sekarang</a></p>
                </div>
            </div>
            <div class="col-lg-7">
                <div class="hero-img-wrap">
                    <img src="<?php echo e(asset('assets/img/bowl-3.png')); ?>" class="img-fluid">
                </div>
            </div>
        </div>
    </div>
</div>

<div class="product-section">
    <div class="container">
        <div class="row">

            <!-- Start Column 1 -->
            <div class="col">
                <h2 class="mb-4 section-title">Pesan Makananmu Sekarang</h2>
                <p class="mb-4">Menu di restoran kami adalah pilihan hidangan yang dipilih dengan cermat yang akan menggoda selera Anda dan membuat Anda merasa puas. Kami hanya menggunakan bahan-bahan paling segar, yang bersumber dari peternakan dan pemasok lokal, untuk menciptakan hidangan yang lezat dan berkelanjutan. </p>
                
            </div> 
            <!-- End Column 1 -->
  
            

        </div>
    </div>
</div>
<!-- End Product Section -->
    <div class="py-5">
        <div class="container">
            <div class="row">
                <h2 class="mb-4 section-title">Categories</h2>
                <div class="owl-carousel owl-theme">
                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="item">
                                <a href="<?php echo e(url('view-categories/'.$item->slug)); ?>">
                                <div class="card">
                                    <img src="<?php echo e(asset('assets/uploads/categories/'.$item->image)); ?>" alt="">
                                    
                                </div>
                                </a>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
    </div>

    <div class="py-5">
        <div class="container">
            <div class="row">
                <h2 class="mb-4 section-title">Menus</h2>
                <div class="owl-carousel owl-theme">
                        <?php $__currentLoopData = $featured_menu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="item">
                                <a href="<?php echo e(url('view-categories/'.$item->Categories->slug.'/'.$item->slug)); ?>">
                                <div class="card">
                                    <img src="<?php echo e(asset('assets/uploads/menu/'.$item->image)); ?>" alt="">
                                    <div class="card-body">
                                        <h5><?php echo e($item->name); ?></h5>
                                        <?php if($item->menu_price == NULL): ?>
                                        <span class="float-end"><?php echo e($item->original_price); ?></span>
                                        <?php else: ?>
                                        <span class="float-start"><?php echo e($item->menu_price); ?></span>
                                        <span class="float-end"><s><?php echo e($item->original_price); ?></s></span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                                </a>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
    </div>

    <!-- Start Popular Product -->
		<div class="popular-product">
			<div class="container">
				<div class="row">
                    <H2 class="text-center mb-4 section-title">Features</H2>
					<div class="col-12 col-md-6 col-lg-4 mb-4 mb-lg-0">
						<div class="product-item-sm d-flex">
							<div class="thumbnail">
								<img src="<?php echo e(asset('assets/img/chat.png')); ?>" alt="Image" class="img-fluid">
							</div>
							<div class="pt-3">
								<h3>Chatbot</h3>
								<p>Anda bisa mencoba chatbot yang akan membantu anda dalam menggunakan web ini</p>
								<p><a href="chatbot">Read More</a></p>
							</div>
						</div>
					</div>

					<div class="col-12 col-md-6 col-lg-4 mb-4 mb-lg-0">
						<div class="product-item-sm d-flex">
							<div class="thumbnail">
								<img src="<?php echo e(asset('assets/img/normalicon.png')); ?>" alt="Image" class="img-fluid">
							</div>
							<div class="pt-3">
								<h3>Normal</h3>
								<p>Memiliki menu e-commerce seperti yang lain</p>
								<p><a href="view-categories">Read More</a></p>
							</div>
						</div>
					</div>

					<div class="col-12 col-md-6 col-lg-4 mb-4 mb-lg-0">
						<div class="product-item-sm d-flex">
							<div class="thumbnail">
								<img src="<?php echo e(asset('assets/img/3d.png')); ?>" alt="Image" class="img-fluid">
							</div>
							<div class="pt-3">
								<h3>3D Model</h3>
								<p>Anda bisa melihat menu secara 3D</p>
								<p><a href="view-categories">Read More</a></p>
							</div>
						</div>
					</div>

				</div>
			</div>
		</div>
		<!-- End Popular Product -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>
<?php echo $__env->make('layouts.src.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script>
        $(document).ready(function(){
            $('.owl-carousel').owlCarousel({
                loop:true,
                margin:10,
                nav:true,
                dots:false,
                responsive:{
                    0:{
                        items:1
                    },
                    600:{
                        items:3
                    },
                    1000:{
                        items:4
                    }
                }
            })
        });
    </script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Project\NEW\WarungIrfan - Copy - Copy\resources\views/frontend/index.blade.php ENDPATH**/ ?>