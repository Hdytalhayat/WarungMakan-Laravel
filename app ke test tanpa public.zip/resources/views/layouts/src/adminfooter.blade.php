<footer class="footer">
  <div class="container-fluid">
    
  </div>
</footer>