<footer class="footer">
    <p>&copy; 2023 Warung Makan</p>
  </footer><?php /**PATH F:\Project\NEW\WarungIrfan\resources\views/layouts/footer.blade.php ENDPATH**/ ?>