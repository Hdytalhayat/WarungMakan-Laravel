<nav class="custom-navbar navbar navbar navbar-expand-md navbar-dark bg-dark" arial-label="Furni navigation bar">

  <div class="container">
    <a class="navbar-brand" href="<?php echo e(url('/')); ?>">Warung Makan<span>.</span></a>

    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarsFurni" aria-controls="navbarsFurni" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>

    

    <div class="collapse navbar-collapse" id="navbarsFurni">
      <ul class="custom-navbar-nav navbar-nav ms-auto mb-2 mb-md-0">
        <div class="search-box">
          <button class="btn-search"><i class="fas fa-search"></i></button>
          <form action="<?php echo e(url('/search-menu')); ?>" method="POST">
            <?php echo csrf_field(); ?>
          <input type="text" class="input-search " name="menu_name" id="search_menu" placeholder="Type to Search..." required>
          </form>
        </div>
        <li class="nav-item <?php echo e(Request::is('/')?'active':''); ?>">
          <a class="nav-link" href="<?php echo e(url('/')); ?>">Home</a>
        </li>
        <li class="nav-item <?php echo e(Request::is('view-categories')?'active':''); ?>">
          <a class="nav-link" href="<?php echo e(url('view-categories')); ?>">Shop</a>
        </li>
        <li class="nav-item <?php echo e(Request::is('about-us')?'active':''); ?>">
          <a class="nav-link " href="<?php echo e(url('about-us')); ?>">About us</a>
        </li>
        <?php if(auth()->guard()->guest()): ?>
              <?php if(Route::has('login')): ?>
                <li class="nav-item <?php echo e(Request::is('login')?'active':''); ?>">
                  <a class="nav-link" href="<?php echo e(url('login')); ?>"><?php echo e(__('Login')); ?></a>
                </li>
                
              <?php endif; ?>
              <?php if(Route::has('register')): ?>
                <li class="nav-item <?php echo e(Request::is('register')?'active':''); ?>">
                  <a class="nav-link" href="<?php echo e(url('register')); ?>"><?php echo e(__('Register')); ?></a>
                </li>
              <?php endif; ?>
          <?php else: ?>
          <li class="nav-item <?php echo e(Request::is('cart')?'active':''); ?>">
            <a class="nav-link" href="<?php echo e(url('cart')); ?>">
              <i class="material-symbols-outlined">
                shopping_cart
              </i>
              <span class="badge badge-pill bg-primary cart-count">0</span>
            </a>
          </li>
          <li class="nav-item <?php echo e(Request::is('wishlist')?'active':''); ?>">
            <a class="nav-link" href="<?php echo e(url('wishlist')); ?>">
              <i class="material-symbols-outlined">
                favorite
              </i>
              <span class="badge badge-pill bg-danger wishlist-count">0</span>
            </a>
          </li>
          
            <li class="nav-item dropdown">
              <a href="" class="nav-link dropdown-toggle" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                <i class="material-symbols-outlined">
                  person
                </i>
              </a>
              <ul class="dropdown-menu text-black bg-white" aria-labelledby="navbarDropdown">
                
                <?php if(Auth::user()->role_as == '1'): ?>
                <li>
                  <a href="<?php echo e(url('/dashboard')); ?>" class="dropdown-item warna">My Dashboard</a>
                </li>  
                <?php endif; ?>
                <li>
                  <a href="<?php echo e(url('my-order')); ?>" class="dropdown-item warna">My Orders</a>
                </li>
                <li>
                  <a href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault();document.getElementById('logout-form').submit();" class="dropdown-item warna"><?php echo e(__('Logout')); ?></a>
                  <form action="<?php echo e(route('logout')); ?>" method="POST" id="logout-form" class="d-none"><?php echo csrf_field(); ?></form>
                </li>
              </ul>
              
            </li>
            
            
          
          <?php endif; ?>

      </ul>
    </div>
  </div>
    
</nav>

<!-- End Header/Navigation --><?php /**PATH F:\Project\NEW\WarungIrfan - Copy - Copy\resources\views/layouts/src/frontnav.blade.php ENDPATH**/ ?>